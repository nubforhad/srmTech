

<?php $__env->startSection('title', 'FTP Movies'); ?>
<?php $__env->startSection('page-title', 'FTP Movies'); ?>

<?php $__env->startSection('content'); ?>

<div class="py-6">

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">

            <div>
                <h2 class="text-2xl font-bold text-gray-800">
                    FTP Movies
                </h2>

                <p class="mt-1 text-sm text-gray-500">
                    Manage FTP movie links
                </p>
            </div>

            <a
                href="<?php echo e(route('ftp-movies.create')); ?>"
                class="inline-flex items-center justify-center gap-2
                       px-5 py-2.5
                       bg-indigo-600 text-white
                       rounded-xl text-sm font-semibold
                       hover:bg-indigo-700 transition"
            >
                <i class="fa-solid fa-plus"></i>
                Add FTP Movie
            </a>

        </div>


        <?php if(session('success')): ?>

            <div class="mb-5 px-4 py-3 rounded-xl
                        bg-green-50 border border-green-200
                        text-green-700 text-sm">
                <?php echo e(session('success')); ?>

            </div>

        <?php endif; ?>


        <div class="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">

            <div class="overflow-x-auto">

                <table class="w-full text-sm">

                    <thead class="bg-gray-50 border-b border-gray-200">

                        <tr>

                            <th class="px-6 py-4 text-left font-semibold text-gray-600">
                                #
                            </th>

                            <th class="px-6 py-4 text-left font-semibold text-gray-600">
                                Icon
                            </th>

                            <th class="px-6 py-4 text-left font-semibold text-gray-600">
                                Title
                            </th>

                            <th class="px-6 py-4 text-left font-semibold text-gray-600">
                                Sub Title
                            </th>

                            <th class="px-6 py-4 text-left font-semibold text-gray-600">
                                Link
                            </th>

                            <th class="px-6 py-4 text-left font-semibold text-gray-600">
                                Status
                            </th>

                            <th class="px-6 py-4 text-right font-semibold text-gray-600">
                                Action
                            </th>

                        </tr>

                    </thead>


                    <tbody class="divide-y divide-gray-100">

                        <?php $__empty_1 = true; $__currentLoopData = $ftpMovies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                            <tr class="hover:bg-gray-50 transition">

                                <td class="px-6 py-4 text-gray-500">
                                    <?php echo e($ftpMovies->firstItem() + $loop->index); ?>

                                </td>


                                <td class="px-6 py-4">

                                    <div
                                        class="w-11 h-11 rounded-xl
                                               bg-indigo-50 text-indigo-600
                                               flex items-center justify-center
                                               text-xl"
                                    >
                                        <i class="<?php echo e($movie->icon ?: 'fa-solid fa-film'); ?>"></i>
                                    </div>

                                </td>


                                <td class="px-6 py-4">

                                    <div class="font-semibold text-gray-800">
                                        <?php echo e($movie->title); ?>

                                    </div>

                                </td>


                                <td class="px-6 py-4 text-gray-500">
                                    <?php echo e($movie->sub_title ?: '—'); ?>

                                </td>


                                <td class="px-6 py-4">

                                    <a
                                        href="<?php echo e($movie->link); ?>"
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        class="inline-flex items-center gap-1
                                               max-w-xs text-indigo-600
                                               hover:text-indigo-800 hover:underline"
                                    >
                                        <span class="truncate">
                                            <?php echo e($movie->link); ?>

                                        </span>

                                        <i class="fa-solid fa-arrow-up-right-from-square text-xs"></i>
                                    </a>

                                </td>


                                <td class="px-6 py-4">

                                    <?php if($movie->status): ?>

                                        <span
                                            class="inline-flex items-center gap-2
                                                   px-3 py-1.5 rounded-full
                                                   text-xs font-semibold
                                                   bg-green-100 text-green-700"
                                        >
                                            <span class="w-2 h-2 bg-green-500 rounded-full"></span>
                                            Active
                                        </span>

                                    <?php else: ?>

                                        <span
                                            class="inline-flex items-center gap-2
                                                   px-3 py-1.5 rounded-full
                                                   text-xs font-semibold
                                                   bg-red-100 text-red-700"
                                        >
                                            <span class="w-2 h-2 bg-red-500 rounded-full"></span>
                                            Inactive
                                        </span>

                                    <?php endif; ?>

                                </td>


                                <td class="px-6 py-4">

                                    <div class="flex justify-end items-center gap-2">

                                        <a
                                            href="<?php echo e(route('ftp-movies.show', $movie)); ?>"
                                            class="px-3 py-1.5 rounded-lg
                                                   bg-gray-100 text-gray-700
                                                   text-xs font-semibold
                                                   hover:bg-gray-200"
                                        >
                                            View
                                        </a>

                                        <a
                                            href="<?php echo e(route('ftp-movies.edit', $movie)); ?>"
                                            class="px-3 py-1.5 rounded-lg
                                                   bg-indigo-50 text-indigo-600
                                                   text-xs font-semibold
                                                   hover:bg-indigo-100"
                                        >
                                            Edit
                                        </a>

                                        <form
                                            method="POST"
                                            action="<?php echo e(route('ftp-movies.destroy', $movie)); ?>"
                                            onsubmit="return confirm('Are you sure you want to delete this FTP Movie?')"
                                        >
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>

                                            <button
                                                type="submit"
                                                class="px-3 py-1.5 rounded-lg
                                                       bg-red-50 text-red-600
                                                       text-xs font-semibold
                                                       hover:bg-red-100"
                                            >
                                                Delete
                                            </button>

                                        </form>

                                    </div>

                                </td>

                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <tr>

                                <td colspan="7" class="px-6 py-12 text-center">

                                    <div class="text-4xl text-gray-300 mb-3">
                                        <i class="fa-solid fa-film"></i>
                                    </div>

                                    <p class="text-gray-500">
                                        No FTP Movies found.
                                    </p>

                                </td>

                            </tr>

                        <?php endif; ?>

                    </tbody>

                </table>

            </div>


            <?php if($ftpMovies->hasPages()): ?>

                <div class="px-6 py-4 border-t border-gray-200">
                    <?php echo e($ftpMovies->links()); ?>

                </div>

            <?php endif; ?>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/srmtechs/public_html/resources/views/admin/ftp-movies/index.blade.php ENDPATH**/ ?>