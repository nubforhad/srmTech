

<?php $__env->startSection('title', 'Website Settings'); ?>
<?php $__env->startSection('page-title', 'Website Settings'); ?>

<?php $__env->startSection('content'); ?>

<div class="py-6">

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        
        <div class="mb-6">

            <h2 class="text-2xl font-bold text-gray-800">
                Website Settings
            </h2>

            <p class="mt-1 text-sm text-gray-500">
                Manage your website logo, contact information and footer details.
            </p>

        </div>


        
        <?php if(session('success')): ?>

            <div class="mb-6 flex items-center gap-3
                        rounded-xl border border-green-200
                        bg-green-50 px-4 py-3
                        text-sm text-green-700">

                <i class="fa-solid fa-circle-check"></i>

                <span>
                    <?php echo e(session('success')); ?>

                </span>

            </div>

        <?php endif; ?>


        
        <?php if($errors->any()): ?>

            <div class="mb-6 rounded-xl border border-red-200
                        bg-red-50 px-4 py-4 text-red-700">

                <div class="flex items-center gap-2 font-semibold mb-2">
                    <i class="fa-solid fa-circle-exclamation"></i>
                    Please fix the following errors:
                </div>

                <ul class="list-disc list-inside text-sm space-y-1">

                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <li><?php echo e($error); ?></li>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </ul>

            </div>

        <?php endif; ?>


        
        <div class="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">


            
            <div class="px-6 py-5
                        bg-gradient-to-r from-indigo-50 to-white
                        border-b border-gray-200">

                <div class="flex items-center gap-3">

                    <div
                        class="w-11 h-11 rounded-xl
                               bg-indigo-100 text-indigo-600
                               flex items-center justify-center"
                    >
                        <i class="fa-solid fa-gear text-lg"></i>
                    </div>

                    <div>

                        <h3 class="font-semibold text-gray-800">
                            General Settings
                        </h3>

                        <p class="text-sm text-gray-500 mt-1">
                            Update your website information.
                        </p>

                    </div>

                </div>

            </div>


            
            <form
                method="POST"
                action="<?php echo e(route('settings.update')); ?>"
                enctype="multipart/form-data"
            >

                <?php echo csrf_field(); ?>

                <?php echo method_field('PUT'); ?>


                <div class="p-6 space-y-8">


                    

                    <div>

                        <label class="block text-sm font-semibold text-gray-700 mb-3">
                            Website Logo
                        </label>

                        <div class="flex flex-col sm:flex-row
                                    sm:items-center gap-5">

                            
                            <div
                                class="w-28 h-28 rounded-2xl
                                       border border-gray-200
                                       bg-gray-50
                                       flex items-center justify-center
                                       overflow-hidden"
                            >

                                <?php if($setting?->logo): ?>

                                    <img
                                        id="logoPreview"
                                        src="<?php echo e(asset('storage/' . $setting->logo)); ?>"
                                        alt="Website Logo"
                                        class="w-full h-full object-contain p-2"
                                    >

                                <?php else: ?>

                                    <div
                                        id="logoPlaceholder"
                                        class="text-center text-gray-400"
                                    >
                                        <i class="fa-solid fa-image text-3xl"></i>

                                        <p class="text-xs mt-2">
                                            No Logo
                                        </p>
                                    </div>

                                    <img
                                        id="logoPreview"
                                        src=""
                                        alt="Logo Preview"
                                        class="hidden w-full h-full object-contain p-2"
                                    >

                                <?php endif; ?>

                            </div>


                            
                            <div class="flex-1">

                                <input
                                    type="file"
                                    name="logo"
                                    id="logo"
                                    accept="image/jpeg,image/png,image/webp"
                                    class="block w-full text-sm text-gray-600
                                           file:mr-4 file:py-2.5 file:px-4
                                           file:rounded-xl file:border-0
                                           file:bg-indigo-50
                                           file:text-indigo-700
                                           file:font-semibold
                                           hover:file:bg-indigo-100"
                                >

                                <p class="mt-2 text-xs text-gray-500">
                                    JPG, JPEG, PNG or WEBP. Maximum size 2MB.
                                </p>

                                <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                    <p class="mt-1 text-sm text-red-600">
                                        <?php echo e($message); ?>

                                    </p>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>

                        </div>

                    </div>


                    

                    <div>

                        <label
                            for="headline"
                            class="block text-sm font-semibold text-gray-700 mb-2"
                        >
                            Headline
                        </label>

                        <textarea
                            name="headline"
                            id="headline"
                            rows="4"
                            placeholder="Enter your website headline..."
                            class="w-full px-4 py-3
                                   rounded-xl border border-gray-300
                                   text-gray-700
                                   resize-none
                                   focus:border-indigo-500
                                   focus:ring-4
                                   focus:ring-indigo-500/10
                                   outline-none"
                        ><?php echo e(old('headline', $setting?->headline)); ?></textarea>

                        <?php $__errorArgs = ['headline'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                            <p class="mt-1 text-sm text-red-600">
                                <?php echo e($message); ?>

                            </p>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>


                    

                    <div>

                        <div class="flex items-center gap-2 mb-4">

                            <div
                                class="w-8 h-8 rounded-lg
                                       bg-blue-50 text-blue-600
                                       flex items-center justify-center"
                            >
                                <i class="fa-solid fa-address-book text-sm"></i>
                            </div>

                            <h3 class="font-semibold text-gray-800">
                                Contact Information
                            </h3>

                        </div>


                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">


                            
                            <div class="md:col-span-2">

                                <label
                                    for="address"
                                    class="block text-sm font-semibold text-gray-700 mb-2"
                                >
                                    Address
                                </label>

                                <textarea
                                    name="address"
                                    id="address"
                                    rows="3"
                                    placeholder="Enter your address..."
                                    class="w-full px-4 py-3
                                           rounded-xl border border-gray-300
                                           text-gray-700
                                           resize-none
                                           focus:border-indigo-500
                                           focus:ring-4
                                           focus:ring-indigo-500/10
                                           outline-none"
                                ><?php echo e(old('address', $setting?->address)); ?></textarea>

                                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                    <p class="mt-1 text-sm text-red-600">
                                        <?php echo e($message); ?>

                                    </p>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>


                            
                            <div>

                                <label
                                    for="mobile"
                                    class="block text-sm font-semibold text-gray-700 mb-2"
                                >
                                    Mobile
                                </label>

                                <div class="relative">

                                    <div
                                        class="absolute left-4 top-1/2
                                               -translate-y-1/2
                                               text-gray-400"
                                    >
                                        <i class="fa-solid fa-phone"></i>
                                    </div>

                                    <input
                                        type="text"
                                        name="mobile"
                                        id="mobile"
                                        value="<?php echo e(old('mobile', $setting?->mobile)); ?>"
                                        placeholder="+880 1XXXXXXXXX"
                                        class="w-full h-12 pl-11 pr-4
                                               rounded-xl border border-gray-300
                                               focus:border-indigo-500
                                               focus:ring-4
                                               focus:ring-indigo-500/10
                                               outline-none"
                                    >

                                </div>

                                <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                    <p class="mt-1 text-sm text-red-600">
                                        <?php echo e($message); ?>

                                    </p>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>


                            
                            <div>

                                <label
                                    for="email"
                                    class="block text-sm font-semibold text-gray-700 mb-2"
                                >
                                    Email
                                </label>

                                <div class="relative">

                                    <div
                                        class="absolute left-4 top-1/2
                                               -translate-y-1/2
                                               text-gray-400"
                                    >
                                        <i class="fa-solid fa-envelope"></i>
                                    </div>

                                    <input
                                        type="email"
                                        name="email"
                                        id="email"
                                        value="<?php echo e(old('email', $setting?->email)); ?>"
                                        placeholder="info@example.com"
                                        class="w-full h-12 pl-11 pr-4
                                               rounded-xl border border-gray-300
                                               focus:border-indigo-500
                                               focus:ring-4
                                               focus:ring-indigo-500/10
                                               outline-none"
                                    >

                                </div>

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                    <p class="mt-1 text-sm text-red-600">
                                        <?php echo e($message); ?>

                                    </p>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>

                        </div>

                    </div>


                    

                    <div>

                        <div class="flex items-center gap-2 mb-4">

                            <div
                                class="w-8 h-8 rounded-lg
                                       bg-indigo-50 text-indigo-600
                                       flex items-center justify-center"
                            >
                                <i class="fa-solid fa-globe text-sm"></i>
                            </div>

                            <h3 class="font-semibold text-gray-800">
                                Social & Website
                            </h3>

                        </div>


                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">


                            
                            <div>

                                <label
                                    for="fb_link"
                                    class="block text-sm font-semibold text-gray-700 mb-2"
                                >
                                    Facebook Link
                                </label>

                                <div class="relative">

                                    <div
                                        class="absolute left-4 top-1/2
                                               -translate-y-1/2
                                               text-gray-400"
                                    >
                                        <i class="fa-brands fa-facebook"></i>
                                    </div>

                                    <input
                                        type="url"
                                        name="fb_link"
                                        id="fb_link"
                                        value="<?php echo e(old('fb_link', $setting?->fb_link)); ?>"
                                        placeholder="https://facebook.com/yourpage"
                                        class="w-full h-12 pl-11 pr-4
                                               rounded-xl border border-gray-300
                                               focus:border-indigo-500
                                               focus:ring-4
                                               focus:ring-indigo-500/10
                                               outline-none"
                                    >

                                </div>

                                <?php $__errorArgs = ['fb_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                    <p class="mt-1 text-sm text-red-600">
                                        <?php echo e($message); ?>

                                    </p>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>


                            
                            <div>

                                <label
                                    for="website_link"
                                    class="block text-sm font-semibold text-gray-700 mb-2"
                                >
                                    Website Link
                                </label>

                                <div class="relative">

                                    <div
                                        class="absolute left-4 top-1/2
                                               -translate-y-1/2
                                               text-gray-400"
                                    >
                                        <i class="fa-solid fa-link"></i>
                                    </div>

                                    <input
                                        type="url"
                                        name="website_link"
                                        id="website_link"
                                        value="<?php echo e(old('website_link', $setting?->website_link)); ?>"
                                        placeholder="https://example.com"
                                        class="w-full h-12 pl-11 pr-4
                                               rounded-xl border border-gray-300
                                               focus:border-indigo-500
                                               focus:ring-4
                                               focus:ring-indigo-500/10
                                               outline-none"
                                    >

                                </div>

                                <?php $__errorArgs = ['website_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                    <p class="mt-1 text-sm text-red-600">
                                        <?php echo e($message); ?>

                                    </p>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>

                        </div>

                    </div>


                    

                    <div>

                        <label
                            for="footer_text"
                            class="block text-sm font-semibold text-gray-700 mb-2"
                        >
                            Footer Text
                        </label>

                        <textarea
                            name="footer_text"
                            id="footer_text"
                            rows="4"
                            placeholder="Enter footer text..."
                            class="w-full px-4 py-3
                                   rounded-xl border border-gray-300
                                   text-gray-700
                                   resize-none
                                   focus:border-indigo-500
                                   focus:ring-4
                                   focus:ring-indigo-500/10
                                   outline-none"
                        ><?php echo e(old('footer_text', $setting?->footer_text)); ?></textarea>

                        <?php $__errorArgs = ['footer_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                            <p class="mt-1 text-sm text-red-600">
                                <?php echo e($message); ?>

                            </p>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                </div>


                
                <div
                    class="px-6 py-4
                           bg-gray-50
                           border-t border-gray-200
                           flex justify-end"
                >

                    <button
                        type="submit"
                        class="inline-flex items-center gap-2
                               px-6 py-3
                               bg-indigo-600
                               text-white
                               rounded-xl
                               text-sm font-semibold
                               shadow-sm
                               hover:bg-indigo-700
                               focus:outline-none
                               focus:ring-4
                               focus:ring-indigo-500/20
                               transition"
                    >
                        <i class="fa-solid fa-floppy-disk"></i>

                        Save Settings
                    </button>

                </div>

            </form>

        </div>

    </div>

</div>



<script>

    document.getElementById('logo')?.addEventListener('change', function (event) {

        const file = event.target.files[0];

        if (!file) {
            return;
        }

        const reader = new FileReader();

        reader.onload = function (e) {

            const preview = document.getElementById('logoPreview');
            const placeholder = document.getElementById('logoPlaceholder');

            preview.src = e.target.result;
            preview.classList.remove('hidden');

            if (placeholder) {
                placeholder.classList.add('hidden');
            }
        };

        reader.readAsDataURL(file);
    });

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xammp8.2\htdocs\rabby.com\rabbyProject\resources\views/admin/settings/index.blade.php ENDPATH**/ ?>