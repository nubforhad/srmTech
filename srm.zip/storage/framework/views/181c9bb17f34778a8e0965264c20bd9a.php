```blade


<?php $__env->startSection('title', 'NET Apps'); ?>

<?php $__env->startSection('page-title', 'NET Apps'); ?>

<?php $__env->startSection('content'); ?>

<div class="max-w-7xl mx-auto">

    
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">

        <div>
            <h2 class="text-2xl font-bold text-gray-800">
                NET Apps
            </h2>

            <p class="text-sm text-gray-500 mt-1">
                Manage your NET applications
            </p>
        </div>

        <a
            href="<?php echo e(route('net-apps.create')); ?>"
            class="inline-flex items-center justify-center
                   px-4 py-2.5
                   bg-indigo-600
                   text-white
                   text-sm font-medium
                   rounded-lg
                   hover:bg-indigo-700
                   transition"
        >
            + Add NET App
        </a>

    </div>


    
    <?php if(session('success')): ?>

        <div
            class="mb-5 flex items-center
                   px-4 py-3
                   rounded-lg
                   bg-green-50
                   border border-green-200
                   text-green-700"
        >
            <?php echo e(session('success')); ?>

        </div>

    <?php endif; ?>


    
    <?php if(session('error')): ?>

        <div
            class="mb-5 px-4 py-3
                   rounded-lg
                   bg-red-50
                   border border-red-200
                   text-red-700"
        >
            <?php echo e(session('error')); ?>

        </div>

    <?php endif; ?>


    
    <div
        class="bg-white
               rounded-xl
               border border-gray-200
               shadow-sm
               overflow-hidden"
    >

        <div class="overflow-x-auto">

            <table class="w-full text-sm">

                
                <thead class="bg-gray-50 border-b border-gray-200">

                    <tr>

                        <th class="px-6 py-4 text-left font-semibold text-gray-600">
                            #
                        </th>

                        <th class="px-6 py-4 text-left font-semibold text-gray-600">
                            Icon
                        </th>

                        <th class="px-6 py-4 text-left font-semibold text-gray-600">
                            Title
                        </th>

                        <th class="px-6 py-4 text-left font-semibold text-gray-600">
                            Sub Title
                        </th>

                        <th class="px-6 py-4 text-left font-semibold text-gray-600">
                            Status
                        </th>

                        <th class="px-6 py-4 text-right font-semibold text-gray-600">
                            Action
                        </th>

                    </tr>

                </thead>


                
                <tbody class="divide-y divide-gray-100">

                    <?php $__empty_1 = true; $__currentLoopData = $netApps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $netApp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <tr class="hover:bg-gray-50 transition">

                            
                            <td class="px-6 py-4 text-gray-500">
                                <?php echo e($netApps->firstItem() + $loop->index); ?>

                            </td>


                            
                            <td class="px-6 py-4">

                                <div
                                    class="w-11 h-11
                                           rounded-lg
                                           bg-indigo-100
                                           flex items-center
                                           justify-center
                                           text-xl"
                                >
                                    <?php echo e($netApp->icon ?: '📱'); ?>

                                </div>

                            </td>


                            
                            <td class="px-6 py-4">

                                <div class="font-semibold text-gray-800">
                                    <?php echo e($netApp->title); ?>

                                </div>

                            </td>


                            
                            <td class="px-6 py-4 text-gray-500">

                                <?php echo e($netApp->sub_title ?: '—'); ?>


                            </td>


                            
                            <td class="px-6 py-4">

                                <?php if($netApp->status): ?>

                                    <span
                                        class="inline-flex items-center gap-2
                                               px-3 py-1.5
                                               rounded-full
                                               text-xs font-semibold
                                               bg-green-100
                                               text-green-700"
                                    >

                                        <span
                                            class="w-2 h-2
                                                   bg-green-500
                                                   rounded-full"
                                        ></span>

                                        Active

                                    </span>

                                <?php else: ?>

                                    <span
                                        class="inline-flex items-center gap-2
                                               px-3 py-1.5
                                               rounded-full
                                               text-xs font-semibold
                                               bg-red-100
                                               text-red-700"
                                    >

                                        <span
                                            class="w-2 h-2
                                                   bg-red-500
                                                   rounded-full"
                                        ></span>

                                        Inactive

                                    </span>

                                <?php endif; ?>

                            </td>


                            
                            <td class="px-6 py-4">

                                <div class="flex justify-end items-center gap-2">

                                    
                                    <a
                                        href="<?php echo e(route('net-apps.edit', $netApp->id)); ?>"
                                        class="px-3 py-1.5
                                               rounded-lg
                                               bg-indigo-50
                                               text-indigo-600
                                               text-xs font-medium
                                               hover:bg-indigo-100
                                               transition"
                                    >
                                        Edit
                                    </a>


                                    
                                    <form
                                        method="POST"
                                        action="<?php echo e(route('net-apps.destroy', $netApp->id)); ?>"
                                        onsubmit="return confirm('Are you sure you want to delete this NET App?')"
                                    >

                                        <?php echo csrf_field(); ?>

                                        <?php echo method_field('DELETE'); ?>

                                        <button
                                            type="submit"
                                            class="px-3 py-1.5
                                                   rounded-lg
                                                   bg-red-50
                                                   text-red-600
                                                   text-xs font-medium
                                                   hover:bg-red-100
                                                   transition"
                                        >
                                            Delete
                                        </button>

                                    </form>

                                </div>

                            </td>

                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <tr>

                            <td
                                colspan="6"
                                class="px-6 py-12 text-center"
                            >

                                <div class="text-gray-400 text-4xl mb-3">
                                    📱
                                </div>

                                <p class="text-gray-500">
                                    No NET Apps found.
                                </p>

                                <a
                                    href="<?php echo e(route('net-apps.create')); ?>"
                                    class="inline-block mt-3
                                           text-indigo-600
                                           hover:underline
                                           text-sm"
                                >
                                    Add your first NET App
                                </a>

                            </td>

                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>


        
        <?php if($netApps->hasPages()): ?>

            <div class="px-6 py-4 border-t border-gray-200">

                <?php echo e($netApps->links()); ?>


            </div>

        <?php endif; ?>

    </div>

</div>

<?php $__env->stopSection(); ?>
```

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/srmtechs/public_html/resources/views/admin/net-apps/index.blade.php ENDPATH**/ ?>