

<?php $__env->startSection('content'); ?>

<div class="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-6">

    
    <div class="mb-6">

        <h1 class="text-2xl font-bold text-gray-800">
            Edit Category
        </h1>

        <p class="text-sm text-gray-500 mt-1">
            Update category information
        </p>

    </div>


    <?php if($errors->any()): ?>

        <div class="mb-5 p-4 rounded-lg bg-red-50 border border-red-200">

            <ul class="list-disc list-inside text-sm text-red-600">

                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </ul>

        </div>

    <?php endif; ?>


    <form action="<?php echo e(route('categories.update', $category)); ?>"
          method="POST"
          class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">

        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>


        
        <div class="mb-5">

            <label class="block text-sm font-medium text-gray-700 mb-2">
                Title <span class="text-red-500">*</span>
            </label>

            <input type="text"
                   name="title"
                   value="<?php echo e(old('title', $category->title)); ?>"
                   required
                   class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">

        </div>


        
        <div class="mb-5">

            <label class="block text-sm font-medium text-gray-700 mb-2">
                Subtitle
            </label>

            <input type="text"
                   name="subtitle"
                   value="<?php echo e(old('subtitle', $category->subtitle)); ?>"
                   class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">

        </div>


        
        <div class="mb-5">

            <label class="block text-sm font-medium text-gray-700 mb-2">
                Link
            </label>

            <input type="text"
                   name="link"
                   value="<?php echo e(old('link', $category->link)); ?>"
                   placeholder="https://example.com"
                   class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">

        </div>


        
        <div class="mb-6">

            <label class="block text-sm font-medium text-gray-700 mb-2">
                Status
            </label>

            <select name="status"
                    class="w-full px-4 py-2.5 border border-gray-300 rounded-lg">

                <option value="1" <?php echo e(old('status', $category->status) == 1 ? 'selected' : ''); ?>>
                    Active
                </option>

                <option value="0" <?php echo e(old('status', $category->status) == 0 ? 'selected' : ''); ?>>
                    Inactive
                </option>

            </select>

        </div>


        
        <div class="flex items-center justify-end gap-3">

            <a href="<?php echo e(route('categories.index')); ?>"
               class="px-4 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg text-sm font-medium">
                Cancel
            </a>

            <button type="submit"
                    class="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-medium">
                Update Category
            </button>

        </div>

    </form>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xammp8.2\htdocs\rabby.com\rabbyProject\resources\views/admin/categories/edit.blade.php ENDPATH**/ ?>