<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>
        <?php echo e(config('app.name', 'Laravel')); ?>

        <?php if (! empty(trim($__env->yieldContent('title')))): ?>
            - <?php echo $__env->yieldContent('title'); ?>
        <?php endif; ?>
    </title>

    
    <link rel="preconnect" href="https://fonts.bunny.net">

    <link
        href="https://fonts.bunny.net/css?family=figtree:400,500,600,700&display=swap"
        rel="stylesheet"
    />

    
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <?php echo $__env->yieldPushContent('styles'); ?>
</head>


<body class="font-sans antialiased bg-gray-100">

<div
    x-data="{ sidebarOpen: false }"
    class="min-h-screen"
>

    
    <div
        x-show="sidebarOpen"
        x-transition.opacity
        @click="sidebarOpen = false"
        class="fixed inset-0 z-40 bg-black/50 lg:hidden"
        style="display: none;"
    ></div>


    
    <aside
        class="fixed inset-y-0 left-0 z-50 w-64
               bg-slate-900 text-white
               transform transition-transform duration-300
               lg:translate-x-0"
        :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full'"
    >

        
        <div
            class="h-16 flex items-center justify-between
                   px-5 border-b border-slate-700"
        >

            <a
                href="<?php echo e(route('dashboard')); ?>"
                class="flex items-center gap-3"
            >

                
                <div
                    class="w-9 h-9 rounded-lg
                           bg-indigo-600
                           flex items-center justify-center
                           font-bold text-white"
                >
                    A
                </div>

                <span class="text-lg font-bold">
                    Admin Panel
                </span>

            </a>


            
            <button
                @click="sidebarOpen = false"
                type="button"
                class="lg:hidden text-gray-300
                       hover:text-white text-xl"
            >
                &times;
            </button>

        </div>


        
        <nav
            class="p-4 space-y-1
                   h-[calc(100vh-4rem)]
                   overflow-y-auto"
        >

            
            <a
                href="<?php echo e(route('dashboard')); ?>"
                class="flex items-center gap-3
                       px-4 py-3 rounded-lg
                       transition

                       <?php echo e(request()->routeIs('dashboard')
                            ? 'bg-indigo-600 text-white'
                            : 'text-gray-300 hover:bg-slate-800 hover:text-white'); ?>"
            >

                <span class="text-lg">
                    📊
                </span>

                <span>
                    Dashboard
                </span>

            </a>


            
            <a
                href="#"
                class="flex items-center gap-3
                       px-4 py-3 rounded-lg
                       text-gray-300
                       hover:bg-slate-800
                       hover:text-white
                       transition"
            >

                <span class="text-lg">
                    👥
                </span>

                <span>
                    Users
                </span>

            </a>


            
            <a
                href="#"
                class="flex items-center gap-3
                       px-4 py-3 rounded-lg
                       text-gray-300
                       hover:bg-slate-800
                       hover:text-white
                       transition"
            >

                <span class="text-lg">
                    📦
                </span>

                <span>
                    Products
                </span>

            </a>


            
            <a
                href="#"
                class="flex items-center gap-3
                       px-4 py-3 rounded-lg
                       text-gray-300
                       hover:bg-slate-800
                       hover:text-white
                       transition"
            >

                <span class="text-lg">
                    🛒
                </span>

                <span>
                    Orders
                </span>

            </a>


            
            <a
                href="#"
                class="flex items-center gap-3
                       px-4 py-3 rounded-lg
                       text-gray-300
                       hover:bg-slate-800
                       hover:text-white
                       transition"
            >

                <span class="text-lg">
                    📈
                </span>

                <span>
                    Reports
                </span>

            </a>


            
            <a
                href="#"
                class="flex items-center gap-3
                       px-4 py-3 rounded-lg
                       text-gray-300
                       hover:bg-slate-800
                       hover:text-white
                       transition"
            >

                <span class="text-lg">
                    ⚙️
                </span>

                <span>
                    Settings
                </span>

            </a>


            
            <div class="border-t border-slate-700 my-4"></div>


            
            <form
                method="POST"
                action="<?php echo e(route('logout')); ?>"
            >

                <?php echo csrf_field(); ?>

                <button
                    type="submit"
                    class="w-full flex items-center gap-3
                           px-4 py-3 rounded-lg
                           text-red-400
                           hover:bg-red-500/10
                           hover:text-red-300
                           transition"
                >

                    <span class="text-lg">
                        🚪
                    </span>

                    <span>
                        Logout
                    </span>

                </button>

            </form>

        </nav>

    </aside>



    
    <div class="lg:ml-64">


        
        <header
            class="h-16 bg-white border-b border-gray-200
                   flex items-center justify-between
                   px-4 sm:px-6
                   sticky top-0 z-30"
        >

            
            <div class="flex items-center gap-4">

                
                <button
                    @click="sidebarOpen = true"
                    type="button"
                    class="lg:hidden
                           p-2 rounded-lg
                           text-gray-600
                           hover:bg-gray-100"
                >
                    ☰
                </button>


                
                <div>

                    <h1 class="text-lg font-semibold text-gray-800">

                        <?php if (! empty(trim($__env->yieldContent('page-title')))): ?>
                            <?php echo $__env->yieldContent('page-title'); ?>
                        <?php else: ?>
                            Dashboard
                        <?php endif; ?>

                    </h1>

                    <p class="hidden sm:block text-xs text-gray-500">
                        Admin Panel
                    </p>

                </div>

            </div>


            
            <div class="flex items-center gap-3">


                
                <button
                    type="button"
                    class="relative p-2 rounded-lg
                           hover:bg-gray-100
                           text-gray-600"
                >

                    🔔

                    <span
                        class="absolute top-1 right-1
                               w-2 h-2
                               bg-red-500
                               rounded-full"
                    ></span>

                </button>


                
                <div
                    x-data="{ open: false }"
                    class="relative"
                >

                    <button
                        @click="open = !open"
                        type="button"
                        class="flex items-center gap-2
                               p-1.5 rounded-lg
                               hover:bg-gray-100"
                    >

                        
                        <div
                            class="w-9 h-9 rounded-full
                                   bg-indigo-600
                                   text-white
                                   flex items-center justify-center
                                   font-semibold"
                        >

                            <?php echo e(strtoupper(
                                substr(auth()->user()->name ?? 'A', 0, 1)
                            )); ?>


                        </div>


                         
                            <div class="hidden md:block text-left">
                                <p class="text-sm font-semibold text-gray-800">
                                    <?php echo e(auth()->user()->name ?? 'Admin'); ?>

                                </p>
                                <p class="text-xs text-gray-500">
                                    Administrator
                                </p>
                            </div> 


                        <span class="hidden md:block text-gray-400">
                            ▾
                        </span>

                    </button>


                    
                    <div
                        x-show="open"
                        x-transition
                        @click.outside="open = false"
                        class="absolute right-0 mt-2
                               w-48 bg-white
                               rounded-lg shadow-lg
                               border border-gray-200
                               py-2"
                        style="display: none;"
                    >

                        <a
                            href="#"
                            class="block px-4 py-2
                                   text-sm text-gray-700
                                   hover:bg-gray-100"
                        >
                            👤 Profile
                        </a>


                        <a
                            href="#"
                            class="block px-4 py-2
                                   text-sm text-gray-700
                                   hover:bg-gray-100"
                        >
                            ⚙️ Settings
                        </a>


                        <div class="border-t my-2"></div>


                        <form
                            method="POST"
                            action="<?php echo e(route('logout')); ?>"
                        >

                            <?php echo csrf_field(); ?>

                            <button
                                type="submit"
                                class="w-full text-left
                                       px-4 py-2
                                       text-sm text-red-600
                                       hover:bg-red-50"
                            >
                                🚪 Logout
                            </button>

                        </form>

                    </div>

                </div>

            </div>

        </header>



        
        <?php if(isset($header)): ?>

            <header class="bg-white shadow-sm">

                <div
                    class="max-w-7xl mx-auto
                           py-5 px-4
                           sm:px-6 lg:px-8"
                >

                    <?php echo e($header); ?>


                </div>

            </header>

        <?php endif; ?>



        
        <main class="p-4 sm:p-6">

            
            <?php if(session('success')): ?>

                <div
                    class="mb-5 rounded-lg
                           bg-green-50
                           border border-green-200
                           px-4 py-3
                           text-sm text-green-700"
                >
                    <?php echo e(session('success')); ?>

                </div>

            <?php endif; ?>


            
            <?php if(session('error')): ?>

                <div
                    class="mb-5 rounded-lg
                           bg-red-50
                           border border-red-200
                           px-4 py-3
                           text-sm text-red-700"
                >
                    <?php echo e(session('error')); ?>

                </div>

            <?php endif; ?>


            

        </main>

    </div>

</div>


<?php echo $__env->yieldPushContent('scripts'); ?>

</body>
</html>  <?php /**PATH C:\xammp8.2\htdocs\rabby.com\rabbyProject\resources\views/layouts/app.blade.php ENDPATH**/ ?>