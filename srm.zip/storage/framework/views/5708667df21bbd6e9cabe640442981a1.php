

<?php $__env->startSection('title', 'Edit Notice'); ?>

<?php $__env->startSection('page-title', 'Edit Notice'); ?>

<?php $__env->startSection('content'); ?>

<div class="max-w-4xl mx-auto px-3 sm:px-4 lg:px-6 py-4 sm:py-6">

    
    <div class="mb-6">

        <div class="flex items-center gap-3">

            <a href="<?php echo e(route('admin.notices.index')); ?>"
               class="w-9 h-9 flex items-center justify-center
                      rounded-lg bg-slate-100
                      text-slate-600 hover:bg-slate-200">

                <i class="bi bi-arrow-left"></i>

            </a>

            <div>

                <h1 class="text-2xl font-bold text-slate-800">
                    Edit Notice
                </h1>

                <p class="text-sm text-slate-500 mt-1">
                    Update notice information
                </p>

            </div>

        </div>

    </div>


    
    <form action="<?php echo e(route('admin.notices.update', $notice)); ?>"
          method="POST"
          enctype="multipart/form-data">

        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>


        <div class="bg-white border border-slate-200
                    rounded-xl shadow-sm overflow-hidden">

            
            <div class="px-5 py-4 bg-slate-50
                        border-b border-slate-200">

                <h2 class="font-semibold text-slate-800">
                    Notice Information
                </h2>

                <p class="text-xs text-slate-500 mt-1">
                    Update the notice details below
                </p>

            </div>


            <div class="p-5 space-y-5">

                
                <div>

                    <label for="name"
                           class="block text-sm font-semibold text-slate-700 mb-1.5">

                        Name
                        <span class="text-red-500">*</span>

                    </label>

                    <input
                        type="text"
                        name="name"
                        id="name"
                        value="<?php echo e(old('name', $notice->name)); ?>"
                        required
                        class="w-full rounded-lg border border-slate-300
                               px-3 py-2.5 text-sm
                               focus:border-blue-500 focus:ring-2
                               focus:ring-blue-100 outline-none"
                    >

                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-xs text-red-600 mt-1">
                            <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>

                
                <div>

                    <label for="title"
                           class="block text-sm font-semibold text-slate-700 mb-1.5">

                        Title
                        <span class="text-red-500">*</span>

                    </label>

                    <input
                        type="text"
                        name="title"
                        id="title"
                        value="<?php echo e(old('title', $notice->title)); ?>"
                        required
                        class="w-full rounded-lg border border-slate-300
                               px-3 py-2.5 text-sm
                               focus:border-blue-500 focus:ring-2
                               focus:ring-blue-100 outline-none"
                    >

                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-xs text-red-600 mt-1">
                            <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>


                
                <div>

                    <label for="subtitle"
                           class="block text-sm font-semibold text-slate-700 mb-1.5">

                        Subtitle

                    </label>

                    <input
                        type="text"
                        name="subtitle"
                        id="subtitle"
                        value="<?php echo e(old('subtitle', $notice->subtitle)); ?>"
                        class="w-full rounded-lg border border-slate-300
                               px-3 py-2.5 text-sm
                               focus:border-blue-500 focus:ring-2
                               focus:ring-blue-100 outline-none"
                    >

                    <?php $__errorArgs = ['subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-xs text-red-600 mt-1">
                            <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>


                
                <div>

                    <label for="notice_text"
                           class="block text-sm font-semibold text-slate-700 mb-1.5">

                        Notice Text

                    </label>

                    <textarea
                        name="notice_text"
                        id="notice_text"
                        rows="6"
                        class="w-full rounded-lg border border-slate-300
                               px-3 py-2.5 text-sm
                               focus:border-blue-500 focus:ring-2
                               focus:ring-blue-100 outline-none resize-y"
                    ><?php echo e(old('notice_text', $notice->notice_text)); ?></textarea>

                    <?php $__errorArgs = ['notice_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-xs text-red-600 mt-1">
                            <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>


                
                <div>

                    <label for="link"
                           class="block text-sm font-semibold text-slate-700 mb-1.5">

                        Link

                    </label>

                    <input
                        type="url"
                        name="link"
                        id="link"
                        value="<?php echo e(old('link', $notice->link)); ?>"
                        placeholder="https://example.com"
                        class="w-full rounded-lg border border-slate-300
                               px-3 py-2.5 text-sm
                               focus:border-blue-500 focus:ring-2
                               focus:ring-blue-100 outline-none"
                    >

                    <?php $__errorArgs = ['link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-xs text-red-600 mt-1">
                            <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>


                
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">

                    
                    <div>

                        <label for="sort_code"
                               class="block text-sm font-semibold text-slate-700 mb-1.5">

                            Sort Code

                        </label>

                        <input
                            type="number"
                            name="sort_code"
                            id="sort_code"
                            value="<?php echo e(old('sort_code', $notice->sort_code)); ?>"
                            min="0"
                            class="w-full rounded-lg border border-slate-300
                                   px-3 py-2.5 text-sm
                                   focus:border-blue-500 focus:ring-2
                                   focus:ring-blue-100 outline-none"
                        >

                        <?php $__errorArgs = ['sort_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-xs text-red-600 mt-1">
                                <?php echo e($message); ?>

                            </p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>


                    
                    <div>

                        <label class="block text-sm font-semibold text-slate-700 mb-1.5">
                            Status
                        </label>

                        <label class="relative inline-flex items-center cursor-pointer">

                            <input
                                type="checkbox"
                                name="status"
                                value="1"
                                class="sr-only peer"
                                <?php echo e(old('status', $notice->status) ? 'checked' : ''); ?>

                            >

                            <div class="w-11 h-6 bg-slate-300
                                        rounded-full peer
                                        peer-checked:bg-blue-600
                                        after:content-['']
                                        after:absolute
                                        after:top-[2px]
                                        after:left-[2px]
                                        after:bg-white
                                        after:border-gray-300
                                        after:border
                                        after:rounded-full
                                        after:h-5 after:w-5
                                        after:transition-all
                                        peer-checked:after:translate-x-full
                                        peer-checked:after:border-white">
                            </div>

                            <span class="ml-3 text-sm text-slate-600">
                                Active
                            </span>

                        </label>

                    </div>

                </div>


                
                <?php if($notice->image): ?>

                    <div>

                        <label class="block text-sm font-semibold
                                      text-slate-700 mb-2">

                            Current Image

                        </label>

                        <div class="flex items-start gap-4">

                            <img
                                src="<?php echo e(asset('storage/' . $notice->image)); ?>"
                                alt="<?php echo e($notice->title); ?>"
                                class="w-32 h-32 object-cover rounded-lg
                                       border border-slate-200"
                            >

                        </div>

                    </div>

                <?php endif; ?>


                
                <div>

                    <label for="image"
                           class="block text-sm font-semibold text-slate-700 mb-1.5">

                        <?php echo e($notice->image ? 'Change Image' : 'Notice Image'); ?>


                    </label>

                    <input
                        type="file"
                        name="image"
                        id="image"
                        accept="image/jpeg,image/png,image/jpg,image/webp"
                        class="block w-full text-sm text-slate-600
                               file:mr-4 file:py-2.5 file:px-4
                               file:rounded-lg file:border-0
                               file:bg-blue-50 file:text-blue-700
                               file:font-semibold
                               hover:file:bg-blue-100"
                    >

                    <p class="text-xs text-slate-400 mt-1">
                        Leave empty to keep the current image.
                        JPG, JPEG, PNG or WEBP. Maximum 2MB.
                    </p>

                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-xs text-red-600 mt-1">
                            <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                    
                    <div id="imagePreview" class="mt-3 hidden">

                        <p class="text-xs text-slate-500 mb-2">
                            New image preview:
                        </p>

                        <img
                            id="preview"
                            src=""
                            class="w-32 h-32 object-cover
                                   rounded-lg border border-slate-200"
                        >

                    </div>

                </div>

            </div>


            
            <div class="px-5 py-4 bg-slate-50
                        border-t border-slate-200
                        flex flex-col sm:flex-row
                        justify-end gap-3">

                <a href="<?php echo e(route('admin.notices.index')); ?>"
                   class="inline-flex items-center justify-center
                          px-4 py-2.5 rounded-lg
                          bg-white border border-slate-300
                          text-slate-700 text-sm font-semibold
                          hover:bg-slate-100">

                    Cancel

                </a>

                <button
                    type="submit"
                    class="inline-flex items-center justify-center
                           gap-2 px-5 py-2.5
                           rounded-lg bg-blue-600
                           text-white text-sm font-semibold
                           hover:bg-blue-700 transition">

                    <i class="bi bi-check-lg"></i>
                    Update Notice

                </button>

            </div>

        </div>

    </form>

</div>


<script>
    document.getElementById('image').addEventListener('change', function (event) {

        const file = event.target.files[0];
        const previewBox = document.getElementById('imagePreview');
        const preview = document.getElementById('preview');

        if (file) {

            preview.src = URL.createObjectURL(file);
            previewBox.classList.remove('hidden');

        } else {

            preview.src = '';
            previewBox.classList.add('hidden');

        }

    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/srmtechs/public_html/resources/views/admin/notices/edit.blade.php ENDPATH**/ ?>