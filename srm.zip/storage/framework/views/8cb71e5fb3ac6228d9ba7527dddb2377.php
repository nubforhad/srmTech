

<?php $__env->startSection('content'); ?>

<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">

    
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">

        <div>
            <h1 class="text-2xl font-bold text-gray-800">
                Services
            </h1>

            <p class="text-sm text-gray-500 mt-1">
                Manage all services
            </p>
        </div>

        <a href="<?php echo e(route('services.create')); ?>"
           class="inline-flex items-center justify-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-lg transition">
            + Add Service
        </a>

    </div>


    
    <?php if(session('success')): ?>
        <div class="mb-5 px-4 py-3 rounded-lg bg-green-50 border border-green-200 text-green-700">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>


    
    <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">

        <div class="overflow-x-auto">

            <table class="min-w-full divide-y divide-gray-200">

                <thead class="bg-gray-50">

                    <tr>

                        <th class="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">
                            #
                        </th>

                        <th class="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">
                            Service
                        </th>

                        <th class="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">
                            Category
                        </th>

                        <th class="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">
                            Link
                        </th>

                        <th class="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">
                            Icon
                        </th>

                        <th class="px-6 py-3 text-right text-xs font-semibold text-gray-600 uppercase">
                            Action
                        </th>

                    </tr>

                </thead>

                <tbody class="bg-white divide-y divide-gray-200">

                    <?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <tr class="hover:bg-gray-50">

                            <td class="px-6 py-4 text-sm text-gray-600">
                                <?php echo e($loop->iteration); ?>

                            </td>


                            
                            <td class="px-6 py-4">

                                <div class="font-medium text-gray-800">
                                    <?php echo e($service->title); ?>

                                </div>

                                <?php if($service->sub_title): ?>

                                    <div class="text-xs text-gray-500 mt-1">
                                        <?php echo e($service->sub_title); ?>

                                    </div>

                                <?php endif; ?>

                            </td>


                            
                            <td class="px-6 py-4">

                                <?php if($service->category): ?>

                                    <span class="inline-flex px-2.5 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-700">
                                        <?php echo e($service->category->title); ?>

                                    </span>

                                <?php else: ?>

                                    <span class="text-gray-400">
                                        -
                                    </span>

                                <?php endif; ?>

                            </td>


                            
                            <td class="px-6 py-4 text-sm">

                                <?php if($service->link): ?>

                                    <a href="<?php echo e($service->link); ?>"
                                       target="_blank"
                                       class="text-blue-600 hover:underline">
                                        Visit
                                    </a>

                                <?php else: ?>

                                    <span class="text-gray-400">
                                        -
                                    </span>

                                <?php endif; ?>

                            </td>


                            
                            <td class="px-6 py-4">

                                <?php if($service->icon): ?>

                                    <span class="text-xl">
                                        <?php echo $service->icon; ?>

                                    </span>

                                <?php else: ?>

                                    <span class="text-gray-400">
                                        -
                                    </span>

                                <?php endif; ?>

                            </td>


                            
                            <td class="px-6 py-4">

                                <div class="flex justify-end items-center gap-2">

                                    <a href="<?php echo e(route('services.show', $service)); ?>"
                                       class="px-3 py-1.5 text-xs font-medium rounded-lg bg-gray-100 hover:bg-gray-200 text-gray-700">
                                        View
                                    </a>

                                    <a href="<?php echo e(route('services.edit', $service)); ?>"
                                       class="px-3 py-1.5 text-xs font-medium rounded-lg bg-blue-100 hover:bg-blue-200 text-blue-700">
                                        Edit
                                    </a>

                                    <form action="<?php echo e(route('services.destroy', $service)); ?>"
                                          method="POST"
                                          onsubmit="return confirm('Are you sure you want to delete this service?');">

                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>

                                        <button type="submit"
                                                class="px-3 py-1.5 text-xs font-medium rounded-lg bg-red-100 hover:bg-red-200 text-red-700">
                                            Delete
                                        </button>

                                    </form>

                                </div>

                            </td>

                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <tr>

                            <td colspan="6"
                                class="px-6 py-10 text-center text-gray-500">

                                No services found.

                            </td>

                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xammp8.2\htdocs\rabby.com\rabbyProject\resources\views/admin/services/index.blade.php ENDPATH**/ ?>